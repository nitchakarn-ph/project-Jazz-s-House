<?php
        include_once('connectPJ.php');

        $data = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '2';";
        $connectData->set_charset("utf8");
        $resultD = mysqli_query($connectData, $data);

        $data_2 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '3';";
        $connectData->set_charset("utf8");
        $resultD_2 = mysqli_query($connectData, $data_2);

        $data_4 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '4';";
        $connectData->set_charset("utf8");
        $resultD_4 = mysqli_query($connectData, $data_4);

        $data_5 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '5';";
        $connectData->set_charset("utf8");
        $resultD_5 = mysqli_query($connectData, $data_5);

        $data_6 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '6';";
        $connectData->set_charset("utf8");
        $resultD_6 = mysqli_query($connectData, $data_6);

        $data_7 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '7';";
        $connectData->set_charset("utf8");
        $resultD_7 = mysqli_query($connectData, $data_7);

        $data_8 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '8';";
        $connectData->set_charset("utf8");
        $resultD_8 = mysqli_query($connectData, $data_8);

        $data_9 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '9';";
        $connectData->set_charset("utf8");
        $resultD_9 = mysqli_query($connectData, $data_9);

        $data_10 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '10';";
        $connectData->set_charset("utf8");
        $resultD_10 = mysqli_query($connectData, $data_10);

        $data_11 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '11';";
        $connectData->set_charset("utf8");
        $resultD_11 = mysqli_query($connectData, $data_11);

        $data_12 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '12';";
        $connectData->set_charset("utf8");
        $resultD_12 = mysqli_query($connectData, $data_12);

        $data_13 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '13';";
        $connectData->set_charset("utf8");
        $resultD_13 = mysqli_query($connectData, $data_13);

        $data_14 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '14';";
        $connectData->set_charset("utf8");
        $resultD_14 = mysqli_query($connectData, $data_14);

        $data_15 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '15';";
        $connectData->set_charset("utf8");
        $resultD_15 = mysqli_query($connectData, $data_15);

        $data_16 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '16';";
        $connectData->set_charset("utf8");
        $resultD_16 = mysqli_query($connectData, $data_16);

        $data_17 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '17';";
        $connectData->set_charset("utf8");
        $resultD_17 = mysqli_query($connectData, $data_17);

        $data_18 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '18';";
        $connectData->set_charset("utf8");
        $resultD_18 = mysqli_query($connectData, $data_18);

        $data_19 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '19';";
        $connectData->set_charset("utf8");
        $resultD_19 = mysqli_query($connectData, $data_19);

        $data_20 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '20';";
        $connectData->set_charset("utf8");
        $resultD_20 = mysqli_query($connectData, $data_20);

        $data_21 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '21';";
        $connectData->set_charset("utf8");
        $resultD_21 = mysqli_query($connectData, $data_21);

        $data_22 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '22';";
        $connectData->set_charset("utf8");
        $resultD_22 = mysqli_query($connectData, $data_22);

        $data_23 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '23';";
        $connectData->set_charset("utf8");
        $resultD_23 = mysqli_query($connectData, $data_23);

        $data_24 = "SELECT * from menus,menucatalogs where  menucatalog_name = 'เค้ก&เบเกอรี่(Cakes)' and Menu_Catalog = '24';";
        $connectData->set_charset("utf8");
        $resultD_24 = mysqli_query($connectData, $data_24);
            
?>