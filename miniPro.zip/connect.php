<?php
    $conn = new mysqli('localhost','root','','customer');

    if($conn->connect_errno){
        die("connection failed".$conn->connect_error);
       
    }
    
    //echo $conn->connect_errno; //-->error โดยจะแจ้งเป็น number
    //echo '<br>';
    //echo $conn->connect_error; -->error โดยจะแจ้งเป็น ข้อความ
    
?>