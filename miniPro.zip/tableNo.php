<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Table</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/icons/favicon.ico" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->

    <link rel='stylesheet' type='text/css' href='./css/orderStlye.css'>
    <style>
        .tablink {
            background-color: #555;
            color: white;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            font-size: 17px;
            width: 50%;
        }

        .tablink:hover {
            background-color: #777;
        }

        /* Style the tab content */
        .tabcontent {
            color: white;
            display: none;
            padding: 50px;
            text-align: center;
        }

        #empty {
            background-color: red;
        }

        #reservations {
            background-color: #00b300;
        }
    </style>

</head>

<body>
    <?php
    include_once('connectJazz.php');
    $connectData->set_charset("utf8");

        if(isset($_POST['save'])){
            echo "success";

            $data = "SELECT cusUsername,enpID FROM customers,employee";

            $date = date("Y/m/d");
            
            
        }
    
    ?>

    <nav class="navbar navbar-expand-lg navbar navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Jazz's House</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="Home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Menu
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#">Food</a>
                            <a class="dropdown-item" href="#">Drink</a>
                            <a class="dropdown-item" href="#">Bakery</a>
                            <!--<div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Something else here</a>-->
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Promotion</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="order.php">Order</a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <?php if (isset($_SESSION['Name'])) { ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Welcome..<?php echo $_SESSION['Name'] ?>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Setting</a>
                                <a class="dropdown-item" href="#">Help</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logoutCus.php">Logout</a>
                            </div>
                        </li>
                    <?php } else { ?>
                        <li class="nav-item">
                            <a class="nav-link" href="loginCus.php">Login</a>
                        </li>
                    <?php } ?>
                </ul>

            </div>
        </div>
    </nav>

    <br>
    <div class="container">

        <nav class="nav pill-nav nav-fill">
            <a class="nav-item nav-link active" href="#">Table number</a>
            <a class="nav-item nav-link disabled" href="#">My order</a>
            <a class="nav-item nav-link disabled" href="#">Login</a>
        </nav>
        <br>
        <form action="" method="POST">
        <div class="row">
            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 1 </h4>
                        <p class="card-text" style="font-size: 15px;">Username : T01</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN01</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 1</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 2 </h4>
                        <p class="card-text" style="font-size: 15px;">Username : T02</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN02</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 2</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 3 </h4>
                        <p class="card-text" style="font-size: 15px;">Username : T03</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN03</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 3</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 4 </h4>
                        <p class="card-text" style="font-size: 15px;">Username : T04</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN04</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 4</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 5 </h4>
                        <p class="card-text" style="font-size: 15px;">Username : T05</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN05</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 5</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!--========================================================================================--> <br>
        <div class="row">
            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 6 </h4>
                        <p class="card-text" style="font-size: 15px;">Username : T06</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN06</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 6</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 7 </h4>
                        <p class="card-text" style="font-size: 15px;">Username : T07</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN07</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 7</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 8 </h4>
                        <p class="card-text" style="font-size: 15px;">Username : T08</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN08</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 8</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 9 </h9>
                        <p class="card-text" style="font-size: 15px;">Username : T09</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN09</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 9</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm">
                <div class="card text-center bg-light" style="width: 12rem;">
                    <div class="card-body">
                        <h4 class="card-title">No. 10 </h4>
                        <p class="card-text" style="font-size: 15px;">Username : T010</p>
                        <p class="card-text" style="font-size: 15px;">Password : TN010</p>
                    </div>
                    <div class="card-footer">
                        <!--<button type="button" class="btn btn-success btn-sm" name="btn_No1">Book in</button>-->
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" name="btn_No1">
                            Book in
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Table number 10</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <i class="fa fa-check"></i>
                                        You have made a reservation for the table.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" name="save">Save </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        </form>              
    </div>




    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>