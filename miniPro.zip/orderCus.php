<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>orderCus</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Jazz's House</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="Home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Menu
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#">Food</a>
                            <a class="dropdown-item" href="#">Drink</a>
                            <a class="dropdown-item" href="#">Bakery</a>
                            <!--<div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Something else here</a>-->
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Promotion</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="order.php">Order</a>
                    </li>
                    
                </ul>
                <ul class="navbar-nav ml-auto">
                    <?php if (isset($_SESSION['Name'])) { ?>
                        <li class="nav-item">
                            <a href="order.php" class="nav-link btn btn-dark">
                                <span>Chart</span>
                                <span class="badge badge-light btn-lg">3</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Welcome..<?php echo $_SESSION['Name']?>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Setting</a>
                                <a class="dropdown-item" href="#">Help</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logoutCus.php">Logout</a>
                            </div>
                        </li>
                        
                    <?php } else {?>
                            <li class="nav-item">
                                <a class="nav-link" href="loginCus.php">Login</a>
                            </li>
                    <?php } ?>     
                </ul>

            </div>
        </div>
    </nav>
    <br>
    <h3 class="text-center">Order list</h3>
    <p class="text-center text-muted">ที่อยู่ร้าน 945 ตำบลศิลา อำเภอเมือง จังหวัดขอนแก่น 40000</p>
    <p class="text-center text-muted">รหัสพนักงานเคาร์เตอร์ : C00812345</p>
    <p class="text-center text-muted">วันที่และเวลา</p>
    
    <div class="contrainer">
    <div class="row">
        <div class ="col-sm-6">
            <div class="container">
                <div class="card">
                    <div class="card-body">
                        <h3>Billing Address</h3>
                        <div class="form-group row">
                                <label for="username"class="col-md-4 mb-2 col-form-label">Username</label>
                                <div class="col-md-9 mx-auto wrap-input100 validate-input" data-validate="Please enter your name">
                                    <input class="input100"type="text" class="form-control" id="username" name="username" placeholder="username"required autofocus>
                                </div>
                                        <!--<div class="col-sm-9 wrap-input100 validate-input" data-validate="Please enter your name">
                                        <input class="input100"type="text" class="form-control" id="username" name="username" placeholder="username">
                                        <span class="focus-input100"></span>
                                    </div>--> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-25">
                    <div class="card">
                    <div class="card-body">
                    <h4>Cart 
                        <span class="price" style="color:black">
                        <i class="fa fa-shopping-cart"></i> 
                        <b>4</b>
                        </span>
                    </h4>
                    <p><a href="#">Product 1</a> <span class="price">$15</span></p>
                    <p><a href="#">Product 2</a> <span class="price">$5</span></p>
                    <p><a href="#">Product 3</a> <span class="price">$8</span></p>
                    <p><a href="#">Product 4</a> <span class="price">$2</span></p>
                    <hr>
                    <p>Total <span class="price" style="color:black"><b>$30</b></span></p>
                    </div>
                </div>
                </div>
    </div>
    </div>

    <script>
        var closebtns = document.getElementsByClassName("close");
        var i;

        for (i = 0; i < closebtns.length; i++) {
        closebtns[i].addEventListener("click", function() {
            this.parentElement.style.display = 'none';
        });
        }
</script>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
</body>
</html>