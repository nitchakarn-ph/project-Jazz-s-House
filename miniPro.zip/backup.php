        <!--<div class="container">
            <h3>
                <small>Topping</small>
            </h3><br>
            <div class="row">
                <//?php
                while ($cata2 = mysqli_fetch_array($resultD)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<//?php echo $cata2['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p></?php echo $cata2['Menu_Name_Tha'] . " (" . $cata2['Menu_Name_Eng'] . ") " ?></p>
                        <p></?php echo "Menu code : " . $cata2['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : </?php echo $cata2['Menu_Price'] ?> THB</h6>
                        <br>
                         Button trigger modal 
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                </?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>แยม (Yam)</small>
            </h3><br>
            <div class="row">
                </?php
                while ($cata_3 = mysqli_fetch_array($resultD_2)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="</?php echo $cata_3['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p></?php echo $cata_3['Menu_Name_Tha'] . " (" . $cata_3['Menu_Name_Eng'] . ") " ?></p>
                        <p></?php echo "Menu code : " . $cata_3['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : </?php echo $cata_3['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal 
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                </?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>เครื่องดื่ม (Drink)</small>
            </h3><br>
            <div class="row">
                </?php
                while ($cata_4 = mysqli_fetch_array($resultD_4)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<//?php echo $cata_4['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><//?php echo $cata_4['Menu_Name_Tha'] . " (" . $cata_4['Menu_Name_Eng'] . ") " ?></p>
                        <p><//?php echo "Menu code : " . $cata_4['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <//?php echo $cata_4['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal 
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <//?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>ชา (Tea)</small>
            </h3><br>
            <div class="row">
            <?php
                while ($cata_5 = mysqli_fetch_array($resultD_5)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_5['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_5['Menu_Name_Tha'] . " (" . $cata_5['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_5['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_5['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal 
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>กาแฟรสพิเศษ (Special Fravour)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_6 = mysqli_fetch_array($resultD_6)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_6['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_6['Menu_Name_Tha'] . " (" . $cata_6['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_6['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_6['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal 
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>ช็อคโกแลต (Chocoiate)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_7 = mysqli_fetch_array($resultD_7)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_7['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_7['Menu_Name_Tha'] . " (" . $cata_7['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_7['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_7['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>สมูธตี้ (Smoothies)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_8 = mysqli_fetch_array($resultD_8)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_8['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_8['Menu_Name_Tha'] . " (" . $cata_8['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_8['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_8['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>อิตาเลียนโซดา (Italian Soda)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_9 = mysqli_fetch_array($resultD_9)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_9['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_9['Menu_Name_Tha'] . " (" . $cata_9['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_9['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_9['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>ชาอังกฤษ (English Tea)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_10 = mysqli_fetch_array($resultD_10)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_10['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_10['Menu_Name_Tha'] . " (" . $cata_10['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_10['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_10['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>กาแฟสด (Coffee Menu)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_11 = mysqli_fetch_array($resultD_11)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_11['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_11['Menu_Name_Tha'] . " (" . $cata_11['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_11['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_11['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>นม (Milk)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_12 = mysqli_fetch_array($resultD_12)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_12['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_12['Menu_Name_Tha'] . " (" . $cata_12['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_12['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_12['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>อาหารจานเดียว (One dish serve)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_13 = mysqli_fetch_array($resultD_13)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_13['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_13['Menu_Name_Tha'] . " (" . $cata_13['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_13['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_13['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>สเต็ก (Steak)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_14 = mysqli_fetch_array($resultD_14)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_14['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_14['Menu_Name_Tha'] . " (" . $cata_14['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_14['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_14['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>


        <div class="container">
            <h3>
                <small>สลัด (Salad)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_15 = mysqli_fetch_array($resultD_15)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_15['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_15['Menu_Name_Tha'] . " (" . $cata_15['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_15['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_15['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>


        <div class="container">
            <h3>
                <small>สปาเก็ตตี้ (Spaghetti)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_16 = mysqli_fetch_array($resultD_16)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_16['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_16['Menu_Name_Tha'] . " (" . $cata_16['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_16['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_16['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>ผัด (Stir fried)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_17 = mysqli_fetch_array($resultD_17)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_17['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_17['Menu_Name_Tha'] . " (" . $cata_17['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_17['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_17['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>ต้ม (Tom)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_18 = mysqli_fetch_array($resultD_18)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_18['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_18['Menu_Name_Tha'] . " (" . $cata_18['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_18['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_18['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>ยำ (Spice and Sour/Yum)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_19 = mysqli_fetch_array($resultD_19)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_19['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_19['Menu_Name_Tha'] . " (" . $cata_19['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_19['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_19['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>อาหารว่าง (Snacks)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_20 = mysqli_fetch_array($resultD_20)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_20['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_20['Menu_Name_Tha'] . " (" . $cata_20['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_20['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_20['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>ซุป (Soup)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_21 = mysqli_fetch_array($resultD_21)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_21['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_21['Menu_Name_Tha'] . " (" . $cata_21['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_21['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_21['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>บาร์บีคิว (BBQ)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_22 = mysqli_fetch_array($resultD_22)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_22['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_22['Menu_Name_Tha'] . " (" . $cata_22['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_22['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_22['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>

        <div class="container">
            <h3>
                <small>เมนูใหม่ (Additional New Menu)</small>
            </h3><br>
            <div class="row">
                <?php
                while ($cata_23 = mysqli_fetch_array($resultD_23)) {
                    ?>
                    <div class="col-xs-3 col-md-3">
                        <img src="<?php echo $cata_23['Menu_Imge']; ?>" width="100%">
                        <br><br>
                        <p><?php echo $cata_23['Menu_Name_Tha'] . " (" . $cata_23['Menu_Name_Eng'] . ") " ?></p>
                        <p><?php echo "Menu code : " . $cata_23['Menu_Id'] ?></p>
                        <h6 class="text-dark">Price : <?php echo $cata_23['Menu_Price'] ?> THB</h6>
                        <br>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
                            Click here
                        </button>
                        <br><br>
                    </div>

                <?php } ?>
            </div>
        </div>