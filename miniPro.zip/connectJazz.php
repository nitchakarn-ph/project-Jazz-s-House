<?php

    $connectData = new mysqli("localhost","root","","jazz'shouse");
    $connectData->set_charset("utf8");
    if($connectData->connect_errno){
        die("connection failed".$connectData->connect_error);
       
    }

?>